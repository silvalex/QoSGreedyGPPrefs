package gp;

public class Condition {
	public String general;
	public String specific;

	public Condition(String general, String specific) {
		this.general = general;
		this.specific = specific;
	}
}
